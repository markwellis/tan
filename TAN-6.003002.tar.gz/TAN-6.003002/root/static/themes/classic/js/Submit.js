window.addEvent( 'domready', function(){
    var validator = new Form.Validator.Inline( document.id('submit_form') );
} );
